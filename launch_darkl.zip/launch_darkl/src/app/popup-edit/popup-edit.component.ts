import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LaunchDarklyService } from '../launchdarkly.service';

@Component({
  selector: 'app-popup-edit',
  templateUrl: './popup-edit.component.html',
  styleUrls: ['./popup-edit.component.css']
})
export class PopupEditComponent implements OnInit {
  show: any;
  private _subscription: any;

  constructor(private http: HttpClient,private ld: LaunchDarklyService) { 
    debugger;
    this.show = ld.flags['add'];
      this._subscription = ld.flagChange.subscribe((flags) => {
        this.show = flags['add'].current;
      });
  }
notstarted:number=10;
onprogress:number=10;
completed:number=10;
total:number=30;

pernotstarted:number=0;
peronprogress:number=0;
percompleted:number=0;
public now: Date = new Date();
public strtime:string="";

  ngOnInit() {
    this.refresh();
    this.strtime =  this.now.toLocaleTimeString();
  }
  refresh(){
    this.pernotstarted=this.notstarted *100 /(this.notstarted+this.onprogress+this.completed);
    this.peronprogress=this.onprogress *100 /(this.notstarted+this.onprogress+this.completed);
    this.percompleted=this.completed *100 /(this.notstarted+this.onprogress+this.completed);

  }

  deleteProject() {
    
  }
  onRatingChange(event: any){
    console.log(event);
    
  }

}
