import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { initialize, LDClient, LDFlagSet } from 'ldclient-js';
 
@Injectable()
export class LaunchDarklyService {
  ldClient:LDClient;
  flags:LDFlagSet;
  flagChange:Subject<Object> = new Subject<Object>();
  constructor() {
    this.flags = {'add':false};
 
    this.ldClient = initialize("5f6b4b229cc9910a697d1c1b",
      { key: "SAMPLE-USER-KEY", anonymous: true } ,{baseUrl:'www.haha.com'});
 
    this.ldClient.on('change', (flags) => {
      
      if(flags['add'] !== undefined) {
        this.flags['add'] = flags['add'];
      }
      this.flagChange.next(this.flags);
      console.log("Flags updated.")
   });
 
   this.ldClient.on('ready', () => {
     this.setFlags();
   })
  }
 
  setFlags() {
      debugger;
    this.flags = this.ldClient.allFlags();
    this.flagChange.next(this.flags);
    console.log("Flags initialized.");
  }

  init(){
      console.log('Initialize the darlyservice');
  }
 
  changeUser(user) {
    if(user !== "Anonymous") {
      this.ldClient.identify({key: user, name: user, anonymous: false});
    }
    else {
      this.ldClient.identify({key: 'anon', anonymous: true});
    }
  }
 }