import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import { PopupEditComponent } from './popup-edit/popup-edit.component';
import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';
import { HttpClientModule } from '@angular/common/http';
import { LaunchDarklyService } from './launchdarkly.service';
// import { StarRatingModule } from 'angular-star-rating';
// import { NO_ERRORS_SCHEMA } from '@angular/compiler/src/core';

@NgModule({
  declarations: [
    AppComponent,
    PopupEditComponent
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    NgxMaterialTimepickerModule.forRoot(),

  ],
  providers: [LaunchDarklyService, ],
  schemas: [
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
export function initFunction(ld: LaunchDarklyService) {
  return ld.init();
}